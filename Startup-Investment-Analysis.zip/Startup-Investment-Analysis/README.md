# Startup Investment Analysis

This project analyzes startup funding trends in India using Python, MySQL, and Power BI.

## Structure
- `data/`: CSV dataset
- `notebooks/`: Jupyter Notebook for EDA
- `sql/`: SQL schema and insert statements
- `report/`: Final report document
- `powerbi/`: Dashboard (placeholder)
