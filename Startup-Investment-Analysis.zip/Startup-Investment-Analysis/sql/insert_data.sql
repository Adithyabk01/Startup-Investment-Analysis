INSERT INTO startups (startup_name, industry_vertical, sub_vertical, city_location,
investors_name, investment_type, amount_usd, date, year, month)
VALUES 
('Ola', 'Transport', 'Cab Service', 'Bangalore', 'Sequoia Capital', 'Private Equity', 50000000, '2018-01-01', 2018, 'January'),
('Flipkart', 'E-commerce', 'Marketplace', 'Bangalore', 'Tiger Global', 'Private Equity', 100000000, '2018-03-15', 2018, 'March');
