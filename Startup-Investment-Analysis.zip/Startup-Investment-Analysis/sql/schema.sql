CREATE DATABASE startup_funding;
USE startup_funding;

CREATE TABLE startups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    startup_name VARCHAR(100),
    industry_vertical VARCHAR(100),
    sub_vertical VARCHAR(100),
    city_location VARCHAR(100),
    investors_name VARCHAR(200),
    investment_type VARCHAR(50),
    amount_usd BIGINT,
    date DATE,
    year INT,
    month VARCHAR(20)
);
